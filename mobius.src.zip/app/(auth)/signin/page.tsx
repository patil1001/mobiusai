"use client"
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { getUser, setUser } from '@/lib/auth'
import { signIn } from 'next-auth/react'
import PolkadotSignInButton from '@/components/PolkadotSignInButton'

export default function SignInPage() {
  const router = useRouter()

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const email = (form.elements.namedItem('email') as HTMLInputElement).value
    const password = (form.elements.namedItem('password') as HTMLInputElement).value
    if (!email || !password) return
    const existing = getUser()
    const name = existing?.name || email.split('@')[0]
    setUser({ name, email, avatarUrl: existing?.avatarUrl })
    router.push('/dashboard')
  }
  return (
    <main className="min-h-screen grid place-items-center p-6">
      <div className="w-full max-w-md glass rounded-xl p-8">
        <h1 className="text-2xl font-bold">Sign in</h1>
        <p className="text-sm text-white/70 mt-1">Welcome back to MobiusAI</p>
        <form className="mt-6 space-y-4" onSubmit={onSubmit}>
          <input name="email" className="w-full rounded-md bg-black/40 border border-white/10 px-4 py-3 outline-none" placeholder="Email" type="email" />
          <input name="password" className="w-full rounded-md bg-black/40 border border-white/10 px-4 py-3 outline-none" placeholder="Password" type="password" />
          <button className="w-full px-4 py-3 rounded-md bg-primary text-black font-semibold">Sign in</button>
        </form>
        <div className="mt-4 grid gap-2">
          <button type="button" onClick={() => signIn('google', { callbackUrl: '/dashboard' })} className="w-full px-4 py-3 rounded-md border border-white/15">Sign in with Google</button>
          <PolkadotSignInButton />
        </div>
        <p className="text-sm text-white/60 mt-4">
          No account? <Link className="text-primary" href="/signup">Create one</Link>
        </p>
      </div>
    </main>
  )
}

