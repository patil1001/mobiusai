"use client"
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { setUser } from '@/lib/auth'

export default function SignUpPage() {
  const router = useRouter()

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const name = (form.elements.namedItem('name') as HTMLInputElement).value
    const email = (form.elements.namedItem('email') as HTMLInputElement).value
    const password = (form.elements.namedItem('password') as HTMLInputElement).value
    if (!name || !email || !password) return
    setUser({ name, email })
    router.push('/dashboard')
  }
  return (
    <main className="min-h-screen grid place-items-center p-6">
      <div className="w-full max-w-md glass rounded-xl p-8">
        <h1 className="text-2xl font-bold">Create account</h1>
        <p className="text-sm text-white/70 mt-1">Get started with MobiusAI</p>
        <form className="mt-6 space-y-4" onSubmit={onSubmit}>
          <input name="name" className="w-full rounded-md bg-black/40 border border-white/10 px-4 py-3 outline-none" placeholder="Name" />
          <input name="email" className="w-full rounded-md bg-black/40 border border-white/10 px-4 py-3 outline-none" placeholder="Email" type="email" />
          <input name="password" className="w-full rounded-md bg-black/40 border border-white/10 px-4 py-3 outline-none" placeholder="Password" type="password" />
          <button className="w-full px-4 py-3 rounded-md bg-primary text-black font-semibold">Create account</button>
        </form>
        <p className="text-sm text-white/60 mt-4">
          Already have an account? <Link className="text-primary" href="/signin">Sign in</Link>
        </p>
      </div>
    </main>
  )
}

