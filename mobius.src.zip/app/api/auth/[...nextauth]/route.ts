import NextAuth from 'next-auth'
import GoogleProvider from 'next-auth/providers/google'
import Credentials from 'next-auth/providers/credentials'
import { signatureVerify } from '@polkadot/util-crypto'

function buildPolkaChallenge(address: string) {
  const nonce = Math.random().toString(36).slice(2)
  const issuedAt = Date.now()
  return `MobiusAI sign-in\nAddress:${address}\nNonce:${nonce}\nIssuedAt:${issuedAt}`
}

export const authOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID || '',
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || ''
    }),
    Credentials({
      name: 'Email',
      credentials: {
        email: { label: 'Email', type: 'text' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize(creds) {
        const email = creds?.email as string
        const password = creds?.password as string
        if (!email || !password) return null
        return { id: email, name: email.split('@')[0], email }
      }
    }),
    Credentials({
      id: 'polkadot',
      name: 'Polkadot',
      credentials: {
        address: { label: 'address', type: 'text' },
        challenge: { label: 'challenge', type: 'text' },
        signature: { label: 'signature', type: 'text' }
      },
      async authorize(creds) {
        const address = creds?.address as string
        const signature = creds?.signature as string
        const challenge = creds?.challenge as string
        if (!address || !signature || !challenge) return null
        const res = signatureVerify(challenge, signature, address)
        if (!res.isValid) return null
        return { id: address, name: `polkadot:${address.slice(0,6)}…`, email: `${address}@substrate.local` }
      }
    })
  ],
  session: { strategy: 'jwt' as const },
  secret: process.env.NEXTAUTH_SECRET,
}

const handler = NextAuth(authOptions as any)
export { handler as GET, handler as POST }


