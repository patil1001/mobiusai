export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const address = searchParams.get('address') || ''
  if (!address) return new Response('address required', { status: 400 })
  const nonce = Math.random().toString(36).slice(2)
  const issuedAt = Date.now()
  const challenge = `MobiusAI sign-in\nAddress:${address}\nNonce:${nonce}\nIssuedAt:${issuedAt}`
  return new Response(JSON.stringify({ challenge }), { headers: { 'content-type': 'application/json' } })
}

