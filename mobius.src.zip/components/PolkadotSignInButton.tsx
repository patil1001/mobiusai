"use client"
import { web3Enable, web3Accounts, web3FromAddress } from '@polkadot/extension-dapp'
import { signIn } from 'next-auth/react'

export default function PolkadotSignInButton() {
  const onClick = async () => {
    const exts = await web3Enable('MobiusAI')
    if (!exts.length) { alert('Install Polkadot{.js} extension.'); return }
    const accounts = await web3Accounts()
    if (!accounts.length) { alert('No accounts found'); return }
    const address = accounts[0].address
    const res = await fetch(`/api/polka/nonce?address=${encodeURIComponent(address)}`)
    const { challenge } = await res.json()
    const injector = await web3FromAddress(address)
    const sig = await injector.signer.signRaw({ address, data: challenge, type: 'bytes' })
    await signIn('polkadot', { address, challenge, signature: sig.signature, callbackUrl: '/dashboard' })
  }
  return (
    <button type="button" onClick={onClick} className="w-full px-4 py-3 rounded-md border border-white/15">Sign in with Polkadot</button>
  )
}

