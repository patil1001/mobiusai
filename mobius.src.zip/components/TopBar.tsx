"use client"
import Link from 'next/link'
import { useEffect, useRef, useState } from 'react'
import { User, getUser, setUser, clearUser } from '@/lib/auth'

export default function TopBar() {
  const [user, setUserState] = useState<User | null>(null)
  const [open, setOpen] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => { setUserState(getUser()) }, [])

  const onAvatarPick = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => {
      const next = { ...(user as User), avatarUrl: reader.result as string }
      setUser(next)
      setUserState(next)
    }
    reader.readAsDataURL(file)
  }

  return (
    <div className="h-12 px-4 border-b border-white/10 flex items-center justify-between">
      <Link href="/" className="font-extrabold">MobiusAI</Link>
      <div className="relative" onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
        <button className="w-8 h-8 rounded-full bg-white/10 overflow-hidden">
          {user?.avatarUrl ? <img src={user.avatarUrl} alt="avatar" className="w-full h-full object-cover" /> : null}
        </button>
        {open && (
          <div className="absolute right-0 mt-2 w-64 glass rounded-lg p-3 z-20">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-white/10 overflow-hidden">
                {user?.avatarUrl ? <img src={user.avatarUrl} alt="avatar" className="w-full h-full object-cover" /> : null}
              </div>
              <div>
                <div className="font-semibold">{user?.name || 'Guest'}</div>
                <div className="text-xs opacity-70">{user?.email || '—'}</div>
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              <button onClick={() => inputRef.current?.click()} className="px-3 py-1.5 text-sm rounded-md border border-white/15">Edit avatar</button>
              <input ref={inputRef} type="file" className="hidden" accept="image/*" onChange={e => { const f=e.target.files?.[0]; if (f) onAvatarPick(f) }} />
              <Link href="/signin" onClick={() => clearUser()} className="ml-auto px-3 py-1.5 text-sm rounded-md border border-white/15">Sign out</Link>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

